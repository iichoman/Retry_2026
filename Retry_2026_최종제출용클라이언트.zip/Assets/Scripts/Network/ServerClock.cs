using System;
using System.Diagnostics;
using UnityEngine;

// 연출용 서버 시계. 피해 판정은 서버가 담당한다.
public static class ServerClock
{
    private static readonly Stopwatch monotonic = Stopwatch.StartNew();
    private static double offset;
    private static long bestRtt = long.MaxValue;
    private static bool initialized;
    public static long LocalMs => monotonic.ElapsedMilliseconds;
    public static long NowMs => initialized ? (long)(LocalMs + offset) : DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
    public static long RoundTripMs { get; private set; }

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    public static void Reset() { initialized = false; bestRtt = long.MaxValue; RoundTripMs = 0; }

    public static void Observe(long serverTimeMs)
    {
        if (initialized || serverTimeMs <= 0) return;
        offset = serverTimeMs - LocalMs;
        initialized = true;
    }

    public static void Synchronize(long echoedClientMs, long serverTimeMs)
    {
        long received = LocalMs;
        long rtt = received - echoedClientMs;
        if (rtt < 0 || rtt > 10000 || serverTimeMs <= 0) return;
        RoundTripMs = rtt;
        // 지연이 가장 작은 표본에서 왕복 시간의 절반을 편도 지연으로 잡는다.
        if (!initialized || bestRtt == long.MaxValue || rtt <= bestRtt + 5)
        {
            offset = serverTimeMs - (echoedClientMs + received) * 0.5;
            bestRtt = Math.Min(bestRtt, rtt);
            initialized = true;
        }
    }
}

public static class NetworkRuntime
{
    public static bool IsOnline { get; internal set; }
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    private static void Reset() { IsOnline = false; }
}
