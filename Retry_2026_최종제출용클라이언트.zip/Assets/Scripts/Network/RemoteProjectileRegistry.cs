﻿using System.Collections.Generic;
using UnityEngine;

// 서버가 보낸 투사체를 틱 사이에서 보간해 표시한다.
public class RemoteProjectileRegistry : MonoBehaviour
{
    [Tooltip("투사체로 쓸 prefab. 비우면 Cube를 자동 생성.")]
    public GameObject ProjectilePrefab;

    [Tooltip("투사체 한 변의 크기(m). 손 Cube보다 작게 보이는 문제 방지용 고정 크기.")]
    [SerializeField] private Vector3 projectileScale = new Vector3(0.3f, 0.3f, 1.5f);

    private readonly Dictionary<int, GameObject> active = new Dictionary<int, GameObject>();
    private readonly Dictionary<int, Vector3> targetPos = new Dictionary<int, Vector3>();
    private readonly Queue<GameObject> pool = new Queue<GameObject>();
    private const int MaxPooledProjectiles = 96;

    public void OnSpawn(ProjectileSpawn sp)
    {
        if (active.ContainsKey(sp.projectileId)) return;

        if (ProjectilePrefab == null)
        {
            var catalog = CombatVfxCatalog.Load();
            if (catalog != null) ProjectilePrefab = catalog.ProjectilePrefab;
        }
        GameObject go = null;
        while (pool.Count > 0 && go == null) go = pool.Dequeue();
        if (go == null && ProjectilePrefab != null)
        {
            go = Instantiate(ProjectilePrefab);
            go.transform.SetParent(null, true);    // 손에 붙지 않도록 월드 루트로
        }
        else if (go == null)
        {
            go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            var col = go.GetComponent<Collider>();
            if (col != null) Destroy(col);
        }

        // 기획에 맞는 직육면체 스케일(Vector3) 적용
        go.transform.localScale = projectileScale;

        go.name = $"Projectile_{sp.projectileId}";
        Vector3 pos = new Vector3(sp.posX, sp.posY, sp.posZ);
        go.transform.position = pos;
        go.SetActive(true);
        foreach (var trail in go.GetComponentsInChildren<TrailRenderer>(true)) { trail.Clear(); trail.emitting = true; }

        // 진행 방향으로 회전
        Vector3 dir = new Vector3(sp.dirX, sp.dirY, sp.dirZ);
        if (dir.sqrMagnitude > 0.0001f)
            go.transform.rotation = Quaternion.LookRotation(dir.normalized);

        PooledVfxSpawner.Play(CombatVfxKind.Muzzle, pos, go.transform.rotation, 0.65f);

        active[sp.projectileId] = go;
        targetPos[sp.projectileId] = pos;
    }

    public void OnMove(ProjectileMove mv)
    {
        if (active.ContainsKey(mv.projectileId))
            targetPos[mv.projectileId] = new Vector3(mv.posX, mv.posY, mv.posZ);
    }

    public void OnDespawn(ProjectileDespawn dp)
    {
        if (active.TryGetValue(dp.projectileId, out var go) && go != null)
        {
            go.transform.position = new Vector3(dp.posX, dp.posY, dp.posZ);
            if (dp.hitType >= 0 && dp.hitType <= 2)
                PooledVfxSpawner.Play(dp.hitType == 0 ? CombatVfxKind.WallHit : CombatVfxKind.BulletHit,
                    go.transform.position, go.transform.rotation, dp.hitType == 0 ? 0.65f : 0.8f);
            foreach (var trail in go.GetComponentsInChildren<TrailRenderer>(true)) { trail.emitting = false; trail.Clear(); }
            go.SetActive(false);
            go.transform.SetParent(transform, true);
            if (pool.Count < MaxPooledProjectiles) pool.Enqueue(go); else Destroy(go);
        }

        active.Remove(dp.projectileId);
        targetPos.Remove(dp.projectileId);
    }

    private void Update()
    {
        // 서버 틱(50ms) 사이를 보간. 속도가 느리므로 부드럽게 따라감.
        foreach (var kv in active)
        {
            if (kv.Value == null) continue;
            if (targetPos.TryGetValue(kv.Key, out var tp))
                kv.Value.transform.position = Vector3.Lerp(
                    kv.Value.transform.position, tp, Time.deltaTime * 12f);
        }
    }

    private void OnDisable()
    {
        foreach (var go in active.Values) if (go != null) Destroy(go);
        while (pool.Count > 0) { var go = pool.Dequeue(); if (go != null) Destroy(go); }
        active.Clear(); targetPos.Clear();
    }
}
