using UnityEngine;

// 배치 검증용 식별 정보. 이동과 피해는 서버에서 판정한다.
public sealed class DungeonPropObstacle : MonoBehaviour
{
    public int RoomId;
    public int GroupId;
    public DungeonPropLayout.Kind Kind;
    public bool Supported;
}
