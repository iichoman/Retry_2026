﻿using System;
using System.Collections.Generic;
using UnityEngine;
public static class RoomBlueprint {
 public static int Kind(int seed,Room r)=>r.type==RoomType.Boss?4:r.type==RoomType.Reward?(r.bounds.size.x>=24&&r.bounds.size.z>=24&&DungeonSetDressing.Hash(seed^0x5641554c,r.bounds.xMin,r.bounds.zMin)%2!=0?8:5):r.type==RoomType.Exit?6:r.type==RoomType.Start?7:(int)(DungeonSetDressing.Hash(seed,r.bounds.xMin,r.bounds.zMin)%4);
 public static Vector3Int Entrance(Room r){
  int bestSide=4,bestOffset=int.MaxValue;var best=Vector3Int.back;
  foreach(var t in r.doorwayFloorTiles){int[] distances={Math.Abs(t.z-r.bounds.zMin),Math.Abs(t.x-r.bounds.xMin),Math.Abs(t.x-(r.bounds.xMax-1)),Math.Abs(t.z-(r.bounds.zMax-1))};int side=0;for(int i=1;i<4;i++)if(distances[i]<distances[side])side=i;
   int offset=side==0||side==3?Math.Abs(t.x-(r.bounds.xMin+r.bounds.size.x/2)):Math.Abs(t.z-(r.bounds.zMin+r.bounds.size.z/2));
   if(side<bestSide||side==bestSide&&offset<bestOffset){bestSide=side;bestOffset=offset;best=side==0?Vector3Int.back:side==1?Vector3Int.left:side==2?Vector3Int.right:Vector3Int.forward;}
  }return best;
 }
 public static Vector3Int ChestTile(Room r,int u,int v){var f=Entrance(r);int width=f.z!=0?r.bounds.size.x:r.bounds.size.z,depth=f.z!=0?r.bounds.size.z:r.bounds.size.x;int x=(u-10)*width/21,z=(v-10)*depth/21;return new Vector3Int(r.bounds.xMin+r.bounds.size.x/2-f.z*x-f.x*z,0,r.bounds.zMin+r.bounds.size.z/2+f.x*x-f.z*z);}
 public static Vector3Int PropTile(Room r,int u,int v)=>r.type==RoomType.Reward?ChestTile(r,u,v):new Vector3Int(r.bounds.xMin+(2*u+1)*r.bounds.size.x/42,0,r.bounds.zMin+(2*v+1)*r.bounds.size.z/42);
 public static Vector3Int Mirror(Room r,Vector3Int t){if(Entrance(r).z!=0)t.x=2*(r.bounds.xMin+r.bounds.size.x/2)-t.x;else t.z=2*(r.bounds.zMin+r.bounds.size.z/2)-t.z;return t;}
 public static int GuardCount(int seed,Room r)=>1+(int)(DungeonSetDressing.Hash(seed^0x47554152,r.bounds.xMin,r.bounds.zMin)%2);
 public static Vector3Int GuardTile(int seed,Room r,int index){var f=Entrance(r);int side=(index==0?1:-1)*(Kind(seed,r)==8?8:4);return new Vector3Int(r.bounds.xMin+r.bounds.size.x/2-f.z*side+f.x*2,0,r.bounds.zMin+r.bounds.size.z/2+f.x*side+f.z*2);}
 // 서버와 같은 우선순위로 보상방을 최대 세 곳 고른다.
 public static void ApplyAll(DungeonGenerator_ChunkMesh generator, IReadOnlyList<Room> rooms)
 {
     for (int i = 0; i < 3; i++)
     {
         int rewardId = DungeonSetDressing.RewardRoom(generator, true);
         if (rewardId < 0) break;
         foreach (var room in rooms)
             if (room.id == rewardId) room.type = RoomType.Reward;
     }

     foreach (var room in rooms)
     {
         Apply(generator.seed, room, generator.corridorWidth);
         // 방 안을 지나는 복도는 설계도의 벽보다 우선한다.
         foreach (var corridor in generator.Corridors)
         foreach (var tile in corridor.floorTiles)
         {
             if (tile.x < room.bounds.xMin || tile.x >= room.bounds.xMax ||
                 tile.z < room.bounds.zMin || tile.z >= room.bounds.zMax) continue;
             room.blockedTiles.Remove(tile);
             room.floorTiles.Add(tile);
         }
     }
 }

 public static void Apply(int seed, Room room, int corridorWidth)
 {
     var plan = RoomBlueprintData.Plans[Kind(seed, room)];
     room.floorTiles.Clear();
     room.blockedTiles.Clear();
     room.layoutType = RoomLayoutType.Open;

     // 21×21 설계도를 실제 방 크기에 맞춘다.
     for (int x = room.bounds.xMin; x < room.bounds.xMax; x++)
     for (int z = room.bounds.zMin; z < room.bounds.zMax; z++)
     {
         int u = (x - room.bounds.xMin) * 21 / room.bounds.size.x;
         int v = (z - room.bounds.zMin) * 21 / room.bounds.size.z;
         var tile = new Vector3Int(x, 0, z);
         if (plan[v][u] == '#') room.blockedTiles.Add(tile);
         else room.floorTiles.Add(tile);
     }

     // 각 출입구에서 중앙까지 긴 축부터 통로를 낸다.
     int centerX = room.bounds.xMin + room.bounds.size.x / 2;
     int centerZ = room.bounds.zMin + room.bounds.size.z / 2;
     int radius = Math.Max(2, corridorWidth / 2);
     foreach (var door in room.doorwayFloorTiles)
     {
         int x = door.x, z = door.z;
         bool xFirst = Math.Abs(x - centerX) >= Math.Abs(z - centerZ);
         while (x != centerX || z != centerZ)
         {
             Carve(room, x, z, radius);
             if ((xFirst && x != centerX) || z == centerZ) x += Math.Sign(centerX - x);
             else z += Math.Sign(centerZ - z);
         }
         Carve(room, centerX, centerZ, 2);
     }
 }

 static void Carve(Room r,int cx,int cz,int radius){for(int x=cx-radius;x<=cx+radius;x++)for(int z=cz-radius;z<=cz+radius;z++){if(x<r.bounds.xMin||x>=r.bounds.xMax||z<r.bounds.zMin||z>=r.bounds.zMax)continue;var t=new Vector3Int(x,0,z);r.blockedTiles.Remove(t);r.floorTiles.Add(t);}}
 public static IEnumerable<(char marker,Vector3Int tile)> Sockets(int seed,Room r){var rows=RoomBlueprintData.Plans[Kind(seed,r)];var used=new HashSet<Vector3Int>();for(int v=0;v<21;v++)for(int u=0;u<21;u++){char c=rows[v][u];if(c=='.'||c=='#')continue;var t=PropTile(r,u,v);if(c=='L'||c=='N')t=ChestTile(r,u,v);if(used.Add(t))yield return(c,t);}}
 public static Vector3 Size(char c)=>c=='T'?new Vector3(2.4f,1.05f,1.2f):c=='C'?new Vector3(1.5f,1.2f,1.3f):c=='R'?new Vector3(1.6f,.9f,1.4f):c=='B'?new Vector3(2.2f,2.2f,.55f):new Vector3(.85f,1.1f,.85f);
 public static bool Safe(Room r,Vector3Int t,Func<Vector3Int,bool> isWall){if(Math.Abs(t.x-(r.bounds.xMin+r.bounds.size.x/2))<2||Math.Abs(t.z-(r.bounds.zMin+r.bounds.size.z/2))<2)return false;foreach(var d in r.doorwayFloorTiles)if(Math.Abs(d.x-t.x)+Math.Abs(d.z-t.z)<5)return false;for(int x=-1;x<=1;x++)for(int z=-1;z<=1;z++)if(!r.floorTiles.Contains(t+new Vector3Int(x,0,z))||isWall(t+new Vector3Int(x,0,z)))return false;return true;}
}
