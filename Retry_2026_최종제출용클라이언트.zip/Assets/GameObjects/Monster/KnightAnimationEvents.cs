using UnityEngine;

// 하위 모델에서 받은 애니메이션 이벤트를 전투 루트에 전달한다.
public sealed class KnightAnimationEvents : MonoBehaviour
{
    private Monster_Attack attack;
    private void Awake() => attack = GetComponentInParent<Monster_Attack>();
    public void AnimEvent_BeginSwing()
    {
        if (attack != null && attack.isActiveAndEnabled && attack.GetComponent<KnightHeavyAttack>()?.IsActive!=true) attack.AnimEvent_BeginSwing();
    }
    public void AnimEvent_EndSwing() => attack?.AnimEvent_EndSwing();
}
