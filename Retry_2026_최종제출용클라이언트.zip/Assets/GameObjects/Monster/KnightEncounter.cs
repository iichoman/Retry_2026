/// <summary>서버의 기사 소환 규칙과 일치시킨다.</summary>
public static class KnightEncounter
{
    public static bool IsKnightRoom(Room room) => room != null && room.type == RoomType.Reward;
}
